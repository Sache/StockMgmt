/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stock;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.*;


/**
 *
 * @author sk3998h
 */
public class UpdateStock extends 
        JFrame implements ActionListener{
    JButton addItem = new JButton("Update Stock");
    JTextField stockNo = new JTextField(7);
    JTextField inputStock = new JTextField(7);
    JTextArea info = new JTextArea(3,50);
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JCheckBox keyOkay = new JCheckBox();
    
    public UpdateStock(){
        setLayout(new BorderLayout());
        setBounds(600, 300, 600, 150);
        setTitle("Update Stock");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        JPanel top = new JPanel();
        top.add(new JLabel("Enter Product Key:"));
        top.add(stockNo,top);
        top.add(keyOkay);
        keyOkay.addActionListener(this);
        
        add("North", top);
        JPanel center = new JPanel();
        center.add(info, center);
        add("Center", center);
 
        JPanel south = new JPanel();
        south.add(new JLabel("New Arrived Stock:" ));
        south.add(inputStock);
        inputStock.setText("0");
        south.add(addItem);
        addItem.addActionListener(this);
        add("South", south);
        
        
        setResizable(false);
        setVisible (true);
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
         String key = stockNo.getText();
      String name = StockData.getName(key);  
      int newStockInput = Integer.parseInt(inputStock.getText());
      if (keyOkay.isEnabled()){
      if (name == null) {
            info.setText("No such item in stock");
        } else {
            info.setText(name);
            info.append("\nPrice: " + pounds.format(StockData.getPrice(key)));
            
            if (e.getSource()== addItem){
             info.append("\nNumber in stock: " + (StockData.getQuantity(key)+ newStockInput));    
            } else {
             info.append("\nNumber in stock: " + StockData.getQuantity(key));    
            }
      }
       
    }
    }
}

