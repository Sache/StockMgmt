
package stock;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.*;
import java.text.*;

/**
 *
 * @author Sandesh
 */
public class PurchaseItem extends 
        JFrame implements ActionListener{
    JTextField keyNo = new JTextField(7);
    JButton buyButton = new JButton("Add to basket");
    JTextArea info = new JTextArea(3, 50);
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    String [] quantityNO= {"1", "2", "3", "4", "5"};
    JComboBox listBox = new JComboBox(quantityNO);
    JTextField total = new JTextField(7);
public PurchaseItem(){
    setLayout(new BorderLayout());
    setBounds(600, 300, 600, 150);
    setTitle("Purchase item");
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    
    JPanel top = new JPanel();
    top.add(new JLabel("Enter key: "));
    top.add(keyNo);
    add("North",top);
    top.add(new JLabel("Input Quantity: "));
    top.add (listBox);
    top.add(buyButton);
    buyButton.addActionListener(this);
    JPanel center = new JPanel();
    center.add(info);
    add("Center", center);
    JPanel south = new JPanel();
    south.add(new JLabel("Total: "));
    south.add(total);
    add("South", south);
    setResizable(false);
    setVisible(true);


 
}

    @Override
    public void actionPerformed(ActionEvent e) {
           String key = keyNo.getText();
      String name = StockData.getName(key);  
      if (name == null) {
            info.setText("No such item in stock");
        } else {
            info.setText(name);
            info.append("\nPrice: " + pounds.format(StockData.getPrice(key)));
            info.append("\nNumber in stock: " + StockData.getQuantity(key));
      if(StockData.getQuantity == 0){
      info.append("\nThere is no stock available for this product at the moment.");
       }
      double totalV = StockData.getPrice(key);
      int quantity = Integer.parseInt(listBox.getSelectedItem().toString());
      double totalValue = (double) (totalV * quantity);
      total.setText(pounds.format(totalValue));

      

    }
    }
}
    
    
    